package br.com.modelo;

import br.com.generico.DefineSegmento;

public class AtendenteComercial implements DefineSegmento {

	@Override
	public String escolhasegmento(String segmento) {
		// TODO Auto-generated method stub
		return (segmento+"Comercial");
	}

}
