package br.com.modelo;

import br.com.generico.DefineSegmento;

public class AtendenteDados {
	
	private String nome;
	private int matricula;
	//private double salarioBase;
	private DefineSegmento segmento;
	
	public AtendenteDados(String nome, int matricula,DefineSegmento segmento) {
		super();
		this.nome = nome;
		this.matricula = matricula;
		//this.salarioBase = salarioBase;
		this.segmento = segmento;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public int getmatricula() {
		return matricula;
	}
	public void setmatricula(int matricula) {
		this.matricula = matricula;
	}

	public DefineSegmento getSegmento() {
		return segmento;
	}
	public void setSegmento(DefineSegmento segmento) {
		this.segmento = segmento;
	}
	
	
	

}
