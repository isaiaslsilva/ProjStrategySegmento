package br.com.generico;

public interface DefineSegmento {
	
	public String escolhasegmento(String segmento);

}
