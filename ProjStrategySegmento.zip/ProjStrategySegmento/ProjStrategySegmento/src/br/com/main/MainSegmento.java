package br.com.main;

import br.com.modelo.AtendenteTecnico;
import br.com.modelo.AtendenteComercial;
import br.com.modelo.AtendenteDados;
import br.com.modelo.AtendenteVendas;
//import br.com.generico.DefineSegmento;

public class MainSegmento {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AtendenteDados AtendenteVendas = new AtendenteDados("Isaias Leal",806588,new AtendenteVendas());
		System.out.println("Atendente De "+AtendenteVendas.getSegmento());
		
		AtendenteDados AtendenteComercial = new AtendenteDados("Jo�o da silva", 888899, new AtendenteComercial());
		System.out.println("Atendente De  "+AtendenteComercial.getSegmento()); 
		
		AtendenteDados AtendenteTecnico = new AtendenteDados("Josefa dos santos",807755,new AtendenteTecnico());
		System.out.println("Atendente De "+AtendenteTecnico.getSegmento()); 		

	}

}
